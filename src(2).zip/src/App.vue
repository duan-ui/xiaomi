<template>
  <div id="app">
     <router-view class="page"/>
      <!-- 存放页面 -->
    <div id="nav">
      <router-link to="/" class="col ihome">首页</router-link> 
      <router-link to="/cat" class="col icat">分类</router-link> 
      <router-link to="/about" class="col iabout">关于</router-link>
      <router-link to="/user" class="col iuser">我的</router-link> 
      <!-- router-link 切换页面导航 -->
    </div>
   
   
  </div>
</template>

<style>
*{
  margin: 0;
  padding: 0;
}
.page{
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: .49rem;

}

#nav {
  display: flex;
  width: 100%;
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  height: .49rem;
  text-align: center;
  background-color: #fff;
  box-shadow: 0 -2px 4px rgba(200, 200,200, .4);
}
a{
  text-decoration: none;
  color: #777;
}
#nav a {
 line-height: .24rem;
 text-align: center;
 flex: 1;
}
.col{
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.col:before{
  content: '';
  display: block;
  width: 0.20rem;
  height: 0.20rem;
  background-image: url("./assets/home.png");
  background-size: cover;
}
 .icat:before{
   background-image: url("./assets/cat.png");
}
 .iabout:before{
   background-image: url("./assets/cart.png");
}
 .iuser:before{
   background-image: url("./assets/user.png");
}
</style>
