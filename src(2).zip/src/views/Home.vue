<template>
  <div class="home">
    <!-- <img alt="Vue logo" src="../assets/logo.png"><br>
  <router-link to="/produce/123" >产品123</router-link><br>
   <router-link to="/produce/abc">产品abc</router-link><br>
    <router-link to="/produce/789? from=China">产品789</router-link> -->

    <div class="na">
			<div><a href=""><img src="../assets/left.png" ></a></div>
			<p>这有家冒菜</p>
			<a href=""><img src="../assets/menu.png" ></a>
		</div>
    <!-- <van-swipe style="height: 200px;" vertical>
      <van-swipe-item><img src="http://16074045.s21i.faiusr.com/2/ABUIABACGAAg3oK_1QUoh-XyoAIwgAU4rAI!900x900.jpg.webp" alt=""></van-swipe-item>
      <van-swipe-item><img src="http://16074045.s21i.faiusr.com/2/ABUIABACGAAg7YK_1QUolKz_lwMwgAU4rAI!900x900.jpg.webp" alt=""></van-swipe-item>
    </van-swipe> -->
		<van-swipe :autoplay="3000" class="swipe">
      <van-swipe-item v-for="(image, index) in images" :key="index">
        <img v-lazy="image" />
      </van-swipe-item>
    </van-swipe>
		<div class="section">
			<ul>
				<li>
					<a href=""><img src="../assets/bian.png" >
		
					</a>
					<p>品牌故事</p>
				</li>
				
				<li>
					<a href=""><img src="../assets/letter.png" >
					
					</a>
					<p>火爆菜品</p>
				</li>
				<li>
					<a href=""><img src="../assets/rocket.png" >
					
					</a>
					<p>新闻资讯</p>
				</li>
				<li>
					<a href=""><img src="../assets/book.png" >
					
					</a>
					<p>联系我们</p>
				</li>
			</ul>
		</div>
		<div class="kuang"></div>
		<div class="list">
			<p>火爆菜品</p>
			<ul>
				<li><img src="../assets/pic2.jpg.webp" ></li>
				<li><img src="../assets/pic3.jpg.webp" ></li>
				<li><img src="../assets/pic1.webp" ></li>
				<li><img src="../assets/pic4.jpg.webp" ></li>
			</ul>
		</div>
		<div class="kuang1"></div>
		<div class="story">
			<p>品牌故事</p>
			<div class="tab">
				<img src="../assets/story.png.webp" >
				<div class="item">
					在西汉时，由于井盐的大量开采和使用，川人“尚滋味，
					好辛香”的饮食习惯已经初步形成。西晋人左思在《蜀都赋》
					中就有“调夫五味”，甘甜之和，......
				</div>
			</div>
		</div>
		<div class="kuang1"></div>
		<div class="project">
			<p>项目优势</p>
			<div class="content">
				没有内容
			</div>
			<div class="kuang1"></div>
			<ul>
				<li><img src="../assets/icon1.png" ></li>
				<li><img src="../assets/icon2.png" ></li>
				<li><img src="../assets/icon6.png" ></li>
				<li><img src="../assets/icon4.png" ></li>
				<li><img src="../assets/icon3.png" ></li>
				<li><img src="../assets/icon5.png" ></li>
			</ul>
		</div>
		<div class="kuang1"></div>
		<div class="together">
			<p>我要合作</p>
			<form action="" method="post">
				<label>姓名:</label><br><br>
				<input type="text" name="txt">&emsp;&emsp;*<br /><br />
				<label>手机:</label><br><br>
				<input type="text" name="txt">&emsp;&emsp;*<br /><br />
				<label>邮箱:</label><br><br>
				<input type="text" name="txt">&emsp;&emsp;*<br /><br />
				<label>地址:</label><br><br>
				<input type="text" name="txt">&emsp;&emsp;*<br /><br />
				<label>留言板:</label><br><br>
				<textarea class="yu"></textarea>&emsp;&emsp;*<br /><br />
				<input type="submit" value="提交" class="jiao">
			</form>
		</div>
		<footer class="footer">
			<ul>
				<li><a href=""><img src="../assets/phone.png" ></a>
				<p>电话咨询</p>
				</li>
				<li><a href=""><img src="../assets/letter1.png" ></a>
				<p>信息咨询</p>
				</li>
				<li><a href=""><img src="../assets/map.png" ></a>
				<p>在线地图</p>
				</li>
				<li><a href=""><img src="../assets/msg.png" ></a>
				<p>在线留言</p>
				</li>
			</ul>
		</footer>
  </div>

  
</template>

<script>
export default {
  data() {
    return {
      images: [
        'http://16074045.s21i.faiusr.com/2/ABUIABACGAAg3oK_1QUoh-XyoAIwgAU4rAI!900x900.jpg.webp',
        'http://16074045.s21i.faiusr.com/2/ABUIABACGAAg7YK_1QUolKz_lwMwgAU4rAI!900x900.jpg.webp'
      ]
    }
  },
  name: 'Home',
  components: {
  
  }
}
</script>
<style>
.na{
	flex:1;
	position: fixed;
	top: 0;
	z-index: 999;
	width: 100%;
	height: .6rem;
	background-color: #DE4D4D;
	display: flex;
	justify-content: space-around;
	align-items: center;
}
.na p{
	font-size: 0.2rem;
	color: #FFFFFF;
}
.na a img{
	width: .35rem;
}
.swipe{
	margin-top: .6rem;
}
.swipe .van-swipe-item img{
  width: 100%;
}	

</style>
