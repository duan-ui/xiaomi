<template>
<div>
    <h1>404</h1>
    <p>糟糕，页面被外星人劫走了</p>
    <button @click="$router.replace('/')">首页</button>
</div>
</template>