<template>
  <div class="about">
    <div class="na">
			<div><a href=""><img src="../assets/left.png" ></a></div>
			<p>这有家冒菜</p>
			<a href=""><img src="../assets/menu.png" ></a>
		</div>
		<div class="story">
			<p>品牌故事</p>
			<div class="fen">
				<img src="../assets/pic5.jpg.webp" >
				<div class="fen-l">
					冒菜最初起源于汉末时期。在西汉时，由于井盐的大量开采和使用，川人
					“尚滋味，好辛香”的饮食习惯已经初步形成。西晋人左思在《蜀都赋》中就有
				</div>
			</div>
			<div class="fen-d">
				就有“调夫五味”，甘甜之和，......五肉七菜，朦厌腥臊，可以练神养血者，
				莫不毕际”的记载，调夫五味讲的就是中药调味方式。“这儿有家冒菜”品牌创
				立于2013年，这是一个互联网外卖结合实体店的新思维品牌，作为互联网新一
				代的代表，它彻底颠覆了传统冒菜业态，在互联网外卖平台表现突出。“这儿有
				家冒菜”对传统冒菜的工艺进行了标准化改良，还原地道老成都风味，门店清新、
				休闲的装修风格引领体验式消费的新概念，给消费者提供轻松惬意的用餐氛围。
			</div>
		</div>
		<div class="kuang1"></div>
		<div class="table">
			<ul>
				<li><img src="../assets/icon8.jpg" ></li>
				<li><img src="../assets/icon9.jpg" ></li>
				<li><img src="../assets/icon8.jpg" ></li>
				<li><img src="../assets/icon10.jpg" ></li>
			</ul>
			<div class="ma">
				<input type="submit" value="上一页" />
				<p>1&ensp;/&ensp;1</p>
				<input type="submit" value="下一页" />
			</div>
		</div>
		
  </div>
</template>
<style scoped>
*{
	margin: 0;padding: 0;
}
.na{
	flex:1;
	position: fixed;
	top: 0;
	z-index: 999;
	width: 100%;
	height: .6rem;
	background-color: #DE4D4D;
	display: flex;
	justify-content: space-around;
	align-items: center;
}
.na p{
	font-size: 0.2rem;
	color: #FFFFFF;
}
.na a img{
	width: .35rem;
}
.story{
	width: 100%;
	margin-top: .6rem;
}
.story p{
	font-size: 0.18rem;
	color: #F55959;
	padding: 0.15rem 0 0 0.13rem;
	border-bottom: 3px solid #DE4D4D;
}
.story .fen{
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: .13rem;
}
.story .fen .fen-l{
	font-size: .14rem;
	/* width: 4rem; */
	color: #333;
	margin-left: 0.1rem;
}
.story .fen img{
	width: 1.9rem;
}
.story .fen-d{
	font-size: 0.16rem;
	color: #333;
}
.kuang1{
	margin-top: .14rem;
	width: 100%;
	height: .1rem;
	background-color: #F7F7F7;
}
.table{
	width: 100%;
	padding-top: .2rem;
	margin-bottom: 1.53rem;
}
.table ul{
	display: flex;
	/* justify-content: space-between; */
	align-items: center;
	flex-wrap: wrap;
	padding: 0.12rem 0 .1rem;
}
.table ul li{
	width: 43%;
	padding: .12rem;
}
.table ul li img{
	width:100%;
}
.table .ma{
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: .12rem .1rem;
}
.table .ma input{
	width: .5rem;
	height: .5rem;
	color: #D24040;
	font-size:.14rem;
	border: #D24040;
}
.table .ma p{
	font-size: .14rem;
}
</style>
